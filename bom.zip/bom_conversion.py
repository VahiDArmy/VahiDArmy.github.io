#!/usr/bin/env python3
"""
Hierarchical BOM converter  --  FORWARD:  Level/PN/ID hierarchy  ->  one BOM list per PN

Based on g04071405.py.  The usual way of running it is unchanged: edit the constants
below and run

    python bom_forward.py

Optional (nothing extra to install; the UI uses tkinter which ships with Python):

    python bom_forward.py --ui                 small window with the column pickers
    python bom_forward.py -i in.xlsx -o out.xlsx
    python bom_forward.py --use-saved          use the column choices saved by the UI
    python bom_forward.py --legacy             old duplicate-assembly handling (see below)
    python bom_forward.py --child-id           add an "ID UM" column (id of the child row)
    python bom_forward.py --no-meta            do not embed the hidden "_meta" sheet

What changed compared with g04071405.py
  1. Duplicate assemblies.  When a PN whose BOM was already captured shows up again
     (e.g. K under P in the example), the old code dropped that row and attached the
     rows below it (J, D, M) to the wrong parent.  Now the row stays in its parent's
     BOM (P -> K) and only the repeated *content* (J, D, M under the 2nd K) is
     ignored, because every PN keeps one BOM.  Use --legacy to get the old result.
  2. Consistency check: a repeated assembly whose children differ from its first
     definition is reported on the "Issues" sheet (with the input row number).
  3. Relation columns R1, R2, R3, R4 ... are all read (before: only R1..R3).
  4. Output column names are matched case-insensitively.
  5. A hidden "_meta" sheet remembers the original column layout so the reverse
     script can rebuild the same layout.  The "BOM" sheet is not affected.
  6. Ids such as 1.5 are kept as written (the old script cut them to 1), and the
     Issues sheet warns about a PN named "X" (clashes with the leaf marker) and about
     ids containing a comma (the comma-separated "ID BOM (of)" list becomes ambiguous).
     With --legacy both behave exactly like the old script.
"""

import argparse
import json
import os
import re
import sys
from collections import Counter, defaultdict, deque

import pandas as pd
from openpyxl import Workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter

# ============================================================
INPUT_FILE  = "input.xlsx"
OUTPUT_FILE = "BOM_output.xlsx"

# ستون‌هایی که متعلق به والد هستند
# مقدار والد در ستون Colx-BOM (of) قرار می‌گیرد
# مقدار فرزند همچنان در ستون Colx باقی می‌ماند
# (Columns that belong to the PARENT: the parent's value goes to "Colx-BOM (of)",
#  the child's value stays in "Colx".)
BOM_COLUMNS = [
    "RK Code",
    "Description",
]

# ترتیب ستون‌های خروجی
# (Order of the output columns.  Columns not listed here are appended at the end.)
OUTPUT_COLUMN_ORDER = [
    "RK Code-BOM (of)",
    "BOM (of)",
    "ID BOM (of)",
    "Description-BOM (of)",
    "RK Code",
    "PN UM",
    "Description",
    "Group UM",
    "Priority UM",
    "QTY UM",
    "Essense",
]

LEGACY_DUPLICATES = False   # True = behave exactly like g04071405.py
CHILD_ID_COLUMN   = False   # True = also write "ID UM" (id of each child row)
EMBED_META        = True    # hidden "_meta" sheet used by the reverse script
# ============================================================

# ---- fixed output keys ------------------------------------------------------
H_BOM      = "BOM (of)"
H_BOM_ID   = "ID BOM (of)"
H_PN       = "PN UM"
H_GROUP    = "Group UM"
H_PRIO     = "Priority UM"
H_QTY      = "QTY UM"
H_CHILD_ID = "ID UM"
BOM_SUFFIX = "-BOM (of)"
FIXED_KEYS = [H_BOM, H_BOM_ID, H_PN, H_GROUP, H_PRIO, H_QTY]
META_SHEET = "_meta"

PRIO_ALIASES = ("priority", "prio", "pri")
QTY_ALIASES  = ("qty", "quantity", "qta")
CORE_NAMES   = {"level", "pn", "id", *PRIO_ALIASES, *QTY_ALIASES}
REL_RE       = re.compile(r"^(?:r|relation)(\d+)$", re.I)


def _print(*a):
    print(*a)


# ---- header helpers (unchanged from the original) ----------------------------
def is_bom_header(name: str) -> bool:
    n = name.lower().strip()
    return (
        n == "bom (of)"
        or n == "id bom (of)"
        or n.endswith("-bom (of)")
        or n.endswith("bom (of)")
    )


def ensure_um_suffix(name: str) -> str:
    if is_bom_header(name):
        return name
    n = name.strip()
    if n.upper().endswith(" UM") or n.upper().endswith("_UM") or n.upper().endswith("-UM"):
        return n
    return n + " UM"


def is_core_name(name: str) -> bool:
    n = str(name).strip().lower()
    return n in CORE_NAMES or bool(REL_RE.match(n))


# ---- settings file (shared with the UI) -------------------------------------
SETTINGS_NAME = "bom_converter_settings.json"


def settings_path() -> str:
    """Next to the scripts if writable, otherwise in the user's home folder.
    (Set the environment variable BOM_CONVERTER_SETTINGS to use another file.)"""
    env = os.environ.get("BOM_CONVERTER_SETTINGS")
    if env:
        return env
    here = os.path.dirname(os.path.abspath(__file__))
    p = os.path.join(here, SETTINGS_NAME)
    try:
        if os.path.exists(p):
            return p
        with open(p, "a", encoding="utf-8"):
            pass
        os.remove(p)
        return p
    except OSError:
        return os.path.join(os.path.expanduser("~"), "." + SETTINGS_NAME)


def load_settings(path=None) -> dict:
    path = path or settings_path()
    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
        return data if isinstance(data, dict) else {}
    except (OSError, ValueError):
        return {}


def save_settings(data: dict, path=None) -> bool:
    path = path or settings_path()
    try:
        with open(path, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
        return True
    except OSError:
        return False


# ---- reading the input -------------------------------------------------------
def read_columns(path, sheet=0):
    """Header only (fast).  Returns (all_columns, extra_columns)."""
    df = pd.read_excel(path, dtype=str, nrows=0, sheet_name=sheet)
    cols = [str(c).strip() for c in df.columns]
    return cols, [c for c in cols if not is_core_name(c)]


def load_from_excel(path, bom_columns, sheet=0, log=_print, legacy=False):
    df = pd.read_excel(path, dtype=str, sheet_name=sheet)
    df.columns = [str(c).strip() for c in df.columns]
    col_lower = {c.lower(): c for c in df.columns}

    for req in ["level", "pn", "id"]:
        if req not in col_lower:
            raise ValueError(f"Missing required column: {req}\nFound: {list(df.columns)}")

    extra_cols = [c for c in df.columns if not is_core_name(c)]
    log(f"Detected extra columns: {extra_cols}")

    bom_cols = []
    for col in bom_columns:
        want = str(col).strip().lower()
        found = next((real for real in df.columns if real.lower() == want), None)
        if found is None:
            log(f"Warning: BOM_COLUMNS entry '{col}' not found")
        elif is_core_name(found):
            log(f"Warning: BOM_COLUMNS entry '{col}' is a core column (Level/PN/ID/R/Priority/QTY) - ignored")
        elif found not in bom_cols:
            bom_cols.append(found)

    # relation columns: R1, R2, ... / Relation1, ... (an index may have both spellings)
    rel_groups = defaultdict(list)
    for low, real in col_lower.items():
        m = REL_RE.match(low)
        if m:
            rel_groups[int(m.group(1))].append((0 if low.startswith("r") and not low.startswith("relation") else 1, real))
    rel_names = [[real for _, real in sorted(rel_groups[n])] for n in sorted(rel_groups)]

    def cell(row, real):
        if real is None:
            return None
        val = row[real]
        if pd.isna(val):
            return None
        val = str(val).strip()
        return val if val else None

    def alias(row, names):
        for nm in names:
            v = cell(row, col_lower.get(nm))
            if v:
                return v
        return None

    data = []
    for idx, row in df.iterrows():
        try:
            level = int(float(row[col_lower['level']]))
        except Exception:
            continue

        pn = str(row[col_lower['pn']]).strip() if pd.notna(row[col_lower['pn']]) else ''
        if not pn:
            continue

        id_raw = row[col_lower['id']]
        id_ = ''
        if pd.notna(id_raw):
            try:
                id_num = float(id_raw)
                if legacy or id_num == int(id_num):
                    id_ = int(id_num)                 # 17.0 -> 17   (old script also cut 1.5 to 1)
                else:
                    id_ = str(id_raw).strip()         # keep 1.5 as '1.5'
            except Exception:
                id_ = str(id_raw).strip()

        prio = alias(row, PRIO_ALIASES)
        if prio is not None:
            try:
                prio = float(prio)
            except Exception:
                pass

        qty = alias(row, QTY_ALIASES)
        if qty is not None:
            try:
                qty = float(qty)
                if qty == int(qty):
                    qty = int(qty)
            except Exception:
                pass

        rels_raw = []
        for names in rel_names:
            v = None
            for real in names:
                v = cell(row, real)
                if v:
                    break
            rels_raw.append(v)

        item = {
            'level': level,
            'pn': pn,
            'id': id_,
            'rels_raw': rels_raw,
            'priority': prio,
            'qty': qty,
            'src_row': int(idx) + 2,      # Excel row number (header = row 1)
        }
        for col in extra_cols:
            val = row[col]
            item[col] = None if pd.isna(val) else (str(val).strip() or None)
        data.append(item)

    if not data:
        raise ValueError("No valid rows found")

    def real_of(names):
        for nm in names:
            if nm in col_lower:
                return col_lower[nm]
        return None

    info = {
        "input_columns": list(df.columns),
        "core": {
            "level": col_lower["level"], "pn": col_lower["pn"], "id": col_lower["id"],
            "priority": real_of(PRIO_ALIASES), "qty": real_of(QTY_ALIASES),
            "rels": [names[0] for names in rel_names],
        },
    }
    return data, extra_cols, bom_cols, info

# ---- building the structure --------------------------------------------------
def _clean_rels(rels_raw):
    rels = set()
    for r in rels_raw or ():
        if r and str(r).strip() and str(r).strip().upper() != 'X':
            rels.add(str(r).strip())
    return rels


def _make_child(row, rels, extra_cols):
    child = {
        'pn': row['pn'],
        'id': row['id'],
        'rels': rels,
        'priority': row.get('priority'),
        'qty': row.get('qty'),
    }
    for col in extra_cols:
        child[col] = row.get(col)
    return child


def _compose_legacy(data, extra_cols, bom_cols, issues):
    """Exactly the stack logic of g04071405.py (kept for comparison)."""
    compositions = defaultdict(list)
    defined = set()
    stack = []
    first_seen = []
    seen = set()
    pn_ids = defaultdict(set)
    pn_attrs = {}
    root_rows = []

    for row in data:
        level = row['level']
        pn = row['pn']
        id_ = row['id']

        if id_ is not None and str(id_).strip() != '':
            pn_ids[pn].add(str(id_))

        if pn not in pn_attrs:
            pn_attrs[pn] = {col: row.get(col) for col in bom_cols}

        while stack and stack[-1][0] >= level:
            _, p_pn = stack.pop()
            if compositions[p_pn]:
                defined.add(p_pn)

        if pn in defined:
            continue

        if pn not in seen:
            seen.add(pn)
            first_seen.append(pn)

        rels = _clean_rels(row.get('rels_raw'))
        if stack:
            compositions[stack[-1][1]].append(_make_child(row, rels, extra_cols))
        else:
            root_rows.append(row)

        stack.append((level, pn))

    while stack:
        _, p_pn = stack.pop()
        if compositions[p_pn]:
            defined.add(p_pn)

    return compositions, first_seen, pn_ids, pn_attrs, root_rows, 0


class _Node:
    __slots__ = ("level", "pn", "skip", "cycle", "shadow", "src_row")

    def __init__(self, level, pn, skip=False, cycle=False, src_row=None):
        self.level, self.pn, self.skip, self.cycle = level, pn, skip, cycle
        self.shadow = []          # direct children seen inside a repeated sub-tree
        self.src_row = src_row


def _compose_fixed(data, extra_cols, bom_cols, issues):
    """
    Same idea as the original, but a repeated assembly stays in its parent's BOM and
    only its repeated content is ignored (every PN keeps the BOM of its first
    definition).  Rows below an ignored occurrence are never attached to another parent.
    """
    compositions = defaultdict(list)
    defined = set()
    stack = []
    first_seen = []
    seen = set()
    pn_ids = defaultdict(set)
    pn_attrs = {}
    root_rows = []
    n_repeat = 0

    def close(node):
        if node.skip:
            if node.shadow and not node.cycle:
                again = Counter(node.shadow)
                if node.pn in defined:
                    first = Counter(c['pn'] for c in compositions[node.pn])
                    if first != again:
                        extra = sorted((again - first).elements())
                        missing = sorted((first - again).elements())
                        issues.append(
                            f"Inconsistent BOM for '{node.pn}' (input row {node.src_row}): children differ "
                            f"from its first definition (extra: {extra or '-'}; missing: {missing or '-'}). "
                            f"The first definition is used."
                        )
                else:
                    issues.append(
                        f"Children {sorted(again)} under '{node.pn}' (input row {node.src_row}) were ignored: "
                        f"'{node.pn}' sits inside a repeated assembly and has no BOM of its own elsewhere."
                    )
            return
        if compositions[node.pn]:
            defined.add(node.pn)

    for row in data:
        level = row['level']
        pn = row['pn']
        id_ = row['id']

        if id_ is not None and str(id_).strip() != '':
            pn_ids[pn].add(str(id_))

        if pn not in pn_attrs:
            pn_attrs[pn] = {col: row.get(col) for col in bom_cols}

        while stack and stack[-1].level >= level:
            close(stack.pop())

        parent = stack[-1] if stack else None

        if parent is not None and parent.skip:
            # inside a repeated assembly: remember the children for the consistency check only
            parent.shadow.append(pn)
            stack.append(_Node(level, pn, skip=True, src_row=row.get('src_row')))
            continue

        repeated = pn in defined
        cycle = (not repeated) and any(n.pn == pn for n in stack)
        if cycle:
            issues.append(
                f"Recursive structure: '{pn}' appears below itself (input row {row.get('src_row')}). "
                f"Its content at this place is ignored."
            )
        if repeated:
            n_repeat += 1

        if pn not in seen:
            seen.add(pn)
            first_seen.append(pn)

        rels = _clean_rels(row.get('rels_raw'))
        if parent is not None:
            compositions[parent.pn].append(_make_child(row, rels, extra_cols))
        else:
            root_rows.append(row)

        stack.append(_Node(level, pn, skip=repeated or cycle, cycle=cycle, src_row=row.get('src_row')))

    while stack:
        close(stack.pop())

    return compositions, first_seen, pn_ids, pn_attrs, root_rows, n_repeat


def _analyze_groups(compositions, issues):
    """Sibling groups from R1..Rn (unchanged logic of the original)."""
    group_info = {}
    next_group_id = 1

    for parent, children in compositions.items():
        child_map = {}
        child_order = []
        for c in children:
            if c['pn'] not in child_map:
                child_map[c['pn']] = c
                child_order.append(c['pn'])

        if len(child_order) < 2:
            for pn in child_order:
                c = child_map[pn]
                if not c['rels'] and c['priority'] is not None:
                    try:
                        if abs(float(c['priority']) - 1.0) > 1e-6:
                            issues.append(
                                f"Priority mismatch for '{pn}' (no relations) under '{parent}': "
                                f"expected 1, got {c['priority']}"
                            )
                    except Exception:
                        pass
            continue

        sibling_set = set(child_order)
        graph = defaultdict(set)
        for pn in child_order:
            for other in child_map[pn]['rels']:
                if other in sibling_set and other != pn:
                    graph[pn].add(other)
                    graph[other].add(pn)

        visited = set()
        components = []
        for start in child_order:
            if start in visited:
                continue
            comp = []
            q = deque([start])
            visited.add(start)
            while q:
                cur = q.popleft()
                comp.append(cur)
                for nei in graph[cur]:
                    if nei not in visited:
                        visited.add(nei)
                        q.append(nei)
            components.append(sorted(comp))

        for comp in components:
            if len(comp) == 1:
                continue

            gid = next_group_id
            next_group_id += 1
            for pn in comp:
                group_info[(parent, pn)] = gid

            for a in comp:
                for b in child_map[a]['rels']:
                    if b in comp and a not in child_map[b]['rels']:
                        issues.append(
                            f"Asymmetric relation under '{parent}': "
                            f"'{a}' lists '{b}' but not vice-versa (group {gid})"
                        )

            for a in comp:
                expected = set(comp) - {a}
                actual = {r for r in child_map[a]['rels'] if r in sibling_set}
                missing = expected - actual
                if missing:
                    issues.append(
                        f"Incomplete group under '{parent}', group {gid}: "
                        f"'{a}' missing {sorted(missing)}"
                    )

            prio_values = []
            for pn in comp:
                p = child_map[pn]['priority']
                if p is not None:
                    try:
                        prio_values.append((pn, float(p)))
                    except Exception:
                        issues.append(f"Invalid priority for '{pn}' under '{parent}': {p}")

            if prio_values:
                total = sum(v for _, v in prio_values)
                if abs(total - 1.0) > 1e-4:
                    issues.append(
                        f"Priority sum != 1 under '{parent}', group {gid}: sum={total:.4f}"
                    )
    return group_info


def _idv(x):
    return None if x is None or str(x).strip() == '' else x


def process_hierarchy(data, extra_cols, bom_cols, legacy=False):
    """Returns (output_rows, issues, stats)."""
    issues = []
    compose = _compose_legacy if legacy else _compose_fixed
    compositions, first_seen, pn_ids, pn_attrs, root_rows, n_repeat = compose(
        data, extra_cols, bom_cols, issues)
    group_info = _analyze_groups(compositions, issues)

    if not legacy:
        x_named = sorted({r['pn'] for r in data if r['pn'].upper() == 'X'})
        if x_named:
            issues.append(
                f"PN {x_named} looks like the leaf marker 'X' of the BOM list. When it is the only child "
                f"of its parent, the reverse converter cannot tell the two apart.")
        with_comma = sorted({str(r['id']) for r in data if ',' in str(r['id'])})
        if with_comma:
            issues.append(
                f"{len(with_comma)} id(s) contain a comma (e.g. '{with_comma[0]}'): the comma-separated "
                f"'ID BOM (of)' list is ambiguous for the reverse converter.")

    output_rows = []
    root_pns = {r['pn'] for r in root_rows}

    for root in root_rows:                      # root product(s) first, blank BOM cells
        row_data = {
            H_BOM: None,
            H_BOM_ID: None,
            H_PN: root['pn'],
            H_GROUP: None,
            H_PRIO: root.get('priority'),
            H_QTY: root.get('qty'),
            H_CHILD_ID: _idv(root['id']),
        }
        for col in extra_cols:
            row_data[col] = root.get(col)
        for col in bom_cols:
            row_data[col + BOM_SUFFIX] = None
        output_rows.append(row_data)

    n_assemblies = n_leaves = 0
    for bom_pn in first_seen:
        children = compositions.get(bom_pn, [])
        parent_ids = ",".join(sorted(pn_ids.get(bom_pn, []), key=lambda x: (len(x), x)))
        parent_attrs = pn_attrs.get(bom_pn, {})

        if children:
            n_assemblies += 1
            for c in children:
                row_data = {
                    H_BOM: bom_pn,
                    H_BOM_ID: parent_ids,
                    H_PN: c['pn'],
                    H_GROUP: group_info.get((bom_pn, c['pn'])),
                    H_PRIO: c['priority'],
                    H_QTY: c['qty'],
                    H_CHILD_ID: _idv(c['id']),
                }
                for col in extra_cols:
                    row_data[col] = c.get(col)
                for col in bom_cols:
                    row_data[col + BOM_SUFFIX] = parent_attrs.get(col)
                output_rows.append(row_data)
        elif bom_pn not in root_pns:
            n_leaves += 1
            row_data = {
                H_BOM: bom_pn,
                H_BOM_ID: parent_ids,
                H_PN: "X",
                H_GROUP: None,
                H_PRIO: None,
                H_QTY: None,
                H_CHILD_ID: None,
            }
            for col in bom_cols:
                row_data[col + BOM_SUFFIX] = parent_attrs.get(col)
            output_rows.append(row_data)

    stats = {
        "rows": len(output_rows), "roots": len(root_rows), "assemblies": n_assemblies,
        "leaves": n_leaves, "repeated_assemblies_kept": n_repeat, "issues": len(issues),
    }
    return output_rows, issues, stats

# ---- output columns ----------------------------------------------------------
def candidate_keys(bom_cols, extra_cols):
    """Every column the converter can write (internal keys, before the ' UM' suffix)."""
    return (list(FIXED_KEYS) + [H_CHILD_ID]
            + [c + BOM_SUFFIX for c in bom_cols] + list(extra_cols))


def resolve_output_columns(order, bom_cols, extra_cols, append_rest=True, strict=False,
                           child_id=False):
    """
    Turn an OUTPUT_COLUMN_ORDER-style list into the list of columns to write.
      append_rest : add BOM/extra columns that are not listed (the original behaviour)
      strict      : drop names that do not exist (default = keep them as empty columns,
                    which is what the original script did)
      child_id    : make sure the optional "ID UM" column is present
    Returns (ordered, missing_names).
    """
    lookup = {}
    for k in candidate_keys(bom_cols, extra_cols):
        lookup.setdefault(k.lower(), k)

    ordered, used, missing = [], set(), []
    for want in order or []:
        w = str(want).strip()
        key = lookup.get(w.lower())
        if key is None:
            missing.append(w)
            if strict:
                continue
            key = w
        if key.lower() in used:
            continue
        ordered.append(key)
        used.add(key.lower())

    if append_rest:
        for col in bom_cols:
            name = col + BOM_SUFFIX
            if name.lower() not in used:
                ordered.append(name)
                used.add(name.lower())
        for col in extra_cols:
            if col.lower() not in used:
                ordered.append(col)
                used.add(col.lower())

    if child_id and H_CHILD_ID.lower() not in used:
        ordered.append(H_CHILD_ID)
    return ordered, missing


def resolve_saved(order, excluded, bom_cols, extra_cols):
    """
    Apply column choices saved by the UI to a (possibly different) file.
    Saved order is kept; saved-but-missing names are reported; columns that are new in
    this file (and were not excluded before) are appended.  Returns (ordered, missing, new).
    """
    ordered, missing = resolve_output_columns(order, bom_cols, extra_cols,
                                              append_rest=False, strict=True)
    skip = {str(e).lower() for e in (excluded or [])}
    used = {k.lower() for k in ordered}
    new = []
    for k in candidate_keys(bom_cols, extra_cols):
        if k.lower() not in used and k.lower() not in skip and k != H_CHILD_ID:
            ordered.append(k)
            used.add(k.lower())
            new.append(k)
    return ordered, missing, new


# ---- writing -----------------------------------------------------------------
def write_output_xlsx(rows, ordered, issues, out_path, meta=None, log=_print):
    final_headers = [ensure_um_suffix(h) for h in ordered]

    # Styles
    bom_fill = PatternFill(start_color="2F5496", end_color="2F5496", fill_type="solid")
    um_fill  = PatternFill(start_color="548235", end_color="548235", fill_type="solid")
    header_font = Font(bold=True, color="FFFFFF", size=9)
    center = Alignment(horizontal="center", vertical="center")
    data_font = Font(size=9)

    thin_border = Border(
        left=Side(style='thin'),
        right=Side(style='thin'),
        top=Side(style='thin'),
        bottom=Side(style='thin')
    )

    # Soft natural warning style (close to Excel Neutral / mild warning)
    x_fill = PatternFill(start_color="FFF2CC", end_color="FFF2CC", fill_type="solid")  # light yellow
    x_font = Font(color="806000", size=9)  # dark amber

    wb = Workbook()
    ws = wb.active
    ws.title = "BOM"

    for c_idx, h in enumerate(final_headers, 1):
        cell = ws.cell(row=1, column=c_idx, value=h)
        cell.font = header_font
        cell.alignment = center
        cell.border = thin_border
        cell.fill = bom_fill if is_bom_header(h) else um_fill

    for r_idx, row_data in enumerate(rows, 2):
        is_x_row = str(row_data.get(H_PN, "")).strip().upper() == "X"

        for c_idx, orig_name in enumerate(ordered, 1):
            val = row_data.get(orig_name)
            if orig_name == H_PRIO and isinstance(val, float):
                if abs(val - 0.5) < 1e-9:
                    val = 0.5
                elif abs(val - 1/3) < 1e-9:
                    val = "1/3"
                elif abs(val - 0.25) < 1e-9:
                    val = 0.25
                else:
                    val = round(val, 6)

            cell = ws.cell(row=r_idx, column=c_idx, value="" if val is None else val)
            cell.alignment = center
            cell.border = thin_border

            if is_x_row:
                cell.fill = x_fill
                cell.font = x_font
            else:
                cell.font = data_font

    for c_idx in range(1, len(final_headers) + 1):
        ws.column_dimensions[get_column_letter(c_idx)].width = 14

    ws.freeze_panes = "A2"

    last_col = get_column_letter(max(1, len(final_headers)))
    last_row = 1 + len(rows)
    ws.auto_filter.ref = f"A1:{last_col}{last_row}"

    ws2 = wb.create_sheet("Issues")
    ws2["A1"] = "Inconsistencies / Warnings"
    ws2["A1"].font = Font(bold=True, size=11)
    if not issues:
        ws2["A3"] = "No inconsistencies detected."
        ws2["A3"].font = Font(color="006600", size=9)
    else:
        ws2["A3"] = f"{len(issues)} issue(s) found:"
        ws2["A3"].font = Font(bold=True, color="CC0000", size=9)
        for idx, msg in enumerate(issues, 4):
            ws2.cell(row=idx, column=1, value=msg).font = Font(size=9)
    ws2.column_dimensions["A"].width = 120

    if meta is not None:
        ws3 = wb.create_sheet(META_SHEET)
        ws3["A1"] = json.dumps(meta, ensure_ascii=False)
        ws3["A2"] = "Used by bom_reverse.py to rebuild the original column layout. Safe to ignore."
        ws3.sheet_state = "hidden"

    wb.save(out_path)
    log(f"Wrote {len(rows)} rows -> {out_path}")
    log(f"Output columns: {final_headers}")
    return final_headers


def convert_file(input_path, output_path, bom_columns=None, output_order=None,
                 legacy=False, child_id=False, embed_meta=True, append_rest=True,
                 strict=False, sheet=0, log=_print):
    """Whole forward conversion.  Returns a dict with rows, issues, stats, headers."""
    bom_columns = BOM_COLUMNS if bom_columns is None else bom_columns
    output_order = OUTPUT_COLUMN_ORDER if output_order is None else output_order

    log(f"Reading: {input_path}")
    data, extra_cols, bom_cols, info = load_from_excel(input_path, bom_columns, sheet, log, legacy=legacy)
    log(f"Loaded {len(data)} rows")
    log(f"BOM columns:   {bom_cols}")

    rows, issues, stats = process_hierarchy(data, extra_cols, bom_cols, legacy=legacy)

    ordered, missing = resolve_output_columns(output_order, bom_cols, extra_cols,
                                              append_rest=append_rest, strict=strict,
                                              child_id=child_id)
    for name in missing:
        if strict:
            log(f"Note: output column '{name}' is not in this file - skipped")
        else:
            log(f"Warning: OUTPUT_COLUMN_ORDER entry '{name}' has no data in this file - written as an empty column")

    if issues:
        log(f"\n=== {len(issues)} INCONSISTENCY(S) ===")
        for msg in issues[:50]:
            log(" ! " + msg)
        if len(issues) > 50:
            log(f" ... and {len(issues) - 50} more (see the Issues sheet)")
    else:
        log("\nNo inconsistencies detected.")
    if stats["repeated_assemblies_kept"]:
        log(f"Repeated assemblies kept in their parent's BOM: {stats['repeated_assemblies_kept']}")

    meta = None
    if embed_meta:
        meta = {
            "format": "bom_flat", "version": 2,
            "input_columns": info["input_columns"],
            "core": info["core"],
            "bom_columns": bom_cols,
            "header_map": {ensure_um_suffix(k): k for k in ordered if k in extra_cols},
            "child_id": H_CHILD_ID in ordered,
            "legacy": bool(legacy),
        }
    seen_h = Counter(ensure_um_suffix(k).lower() for k in ordered)
    for h, n in seen_h.items():
        if n > 1:
            log(f"Warning: {n} output columns end up with the same header '{h}'")
    headers = write_output_xlsx(rows, ordered, issues, output_path, meta=meta, log=log)
    log(f"Done -> {output_path}")
    return {"rows": rows, "issues": issues, "stats": stats, "ordered": ordered, "headers": headers}


# ---- command line ------------------------------------------------------------
def main(argv=None):
    ap = argparse.ArgumentParser(description="Hierarchy (Level/PN/ID) -> BOM list per PN")
    ap.add_argument("-i", "--input", help=f"input xlsx (default {INPUT_FILE})")
    ap.add_argument("-o", "--output", help=f"output xlsx (default {OUTPUT_FILE})")
    ap.add_argument("--sheet", default=0, help="sheet name or index to read (default: first)")
    ap.add_argument("--ui", action="store_true", help="open the optional window")
    ap.add_argument("--use-saved", action="store_true", help="use column choices saved by the UI")
    ap.add_argument("--legacy", action="store_true", help="old duplicate-assembly handling")
    ap.add_argument("--child-id", action="store_true", help='also write "ID UM" (id of each child row)')
    ap.add_argument("--no-meta", action="store_true", help="do not embed the hidden _meta sheet")
    args = ap.parse_args(argv)

    if args.ui:
        try:
            import bom_ui
        except ImportError as e:
            print(f"Cannot start the UI: {e}")
            return 1
        return bom_ui.main(initial_tab="forward")

    sheet = args.sheet
    if isinstance(sheet, str) and sheet.isdigit():
        sheet = int(sheet)

    inp = args.input or INPUT_FILE
    out = args.output or OUTPUT_FILE
    bom_columns, order = BOM_COLUMNS, OUTPUT_COLUMN_ORDER
    append_rest = strict = False
    saved_excluded = None
    if args.use_saved:
        s = load_settings().get("forward", {})
        if s.get("bom_columns") is not None:
            bom_columns = s["bom_columns"]
        if s.get("output_order"):
            order = s["output_order"]
            saved_excluded = s.get("output_excluded", [])
            append_rest = False
            strict = True
        if s.get("bom_columns") is not None or s.get("output_order"):
            print(f"Using the column choices saved in {settings_path()}")
        else:
            print(f"No saved column choices found ({settings_path()}) - using the constants in the script")

    try:
        if saved_excluded is not None:
            # saved choices: keep their order, append columns that are new in this file
            _, extra = read_columns(inp, sheet)
            real_bom = [next((e for e in extra if e.lower() == str(b).strip().lower()), None)
                        for b in bom_columns]
            real_bom = [b for b in real_bom if b]
            ordered, _, new = resolve_saved(order, saved_excluded, real_bom, extra)
            if new:
                print(f"New columns in this file appended at the end: {new}")
            order = ordered
        convert_file(inp, out, bom_columns=bom_columns, output_order=order,
                     legacy=args.legacy or LEGACY_DUPLICATES,
                     child_id=args.child_id or CHILD_ID_COLUMN,
                     embed_meta=EMBED_META and not args.no_meta,
                     append_rest=append_rest, strict=strict, sheet=sheet)
    except (ValueError, OSError) as e:
        print(f"ERROR: {e}")
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())

