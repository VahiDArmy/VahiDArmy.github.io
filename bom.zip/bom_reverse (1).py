#!/usr/bin/env python3
"""
Hierarchical BOM converter  --  REVERSE:  one BOM list per PN  ->  Level/PN/ID hierarchy

Takes the file written by bom_forward.py (BOM sheet) and rebuilds the classical
hierarchical file:  every product (rows with an empty "BOM (of)") is exploded
parent -> children -> grandchildren ...  Level = depth (0 for the product, no jumps).

Default run (edit the constants below, then):

    python bom_reverse.py
    python bom_reverse.py -i BOM_output.xlsx -o hierarchy_rebuilt.xlsx
    python bom_reverse.py --collapse-repeats     # list a repeated assembly's content only once
    python bom_reverse.py --ui

What is restored and what is not
  * Level, PN, Priority, QTY and the extra columns come from the BOM row of each child.
  * R1, R2, ... are rebuilt from "Group UM": every member of a group lists all the others.
  * ID: every PN has the list of its ids in "ID BOM (of)".  The ids are handed out to the
    occurrences of that PN in file order.  If the flat file has an "ID UM" column (forward
    option --child-id) the exact id of every row is used instead.
  * The original row order / level jumps cannot be recovered (the flat list does not
    contain them).  The column layout is restored from the hidden "_meta" sheet when
    it exists.
  * If a PN has only one BOM in the flat list (always true for files written by
    bom_forward.py) the explosion is complete and consistent by construction.
"""

import argparse
import json
import re
import sys
from collections import defaultdict, deque

from openpyxl import Workbook, load_workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter

from bom_forward import (BOM_SUFFIX, H_BOM, H_BOM_ID, H_CHILD_ID, H_GROUP, H_PN, H_PRIO, H_QTY,
                         META_SHEET, REL_RE, is_bom_header)

# ============================================================
INPUT_FILE  = "BOM_output.xlsx"
OUTPUT_FILE = "hierarchy_rebuilt.xlsx"
COLLAPSE_REPEATS = False      # True: a repeated assembly's children are listed only the first time
MAX_ROWS = 1_000_000          # Excel holds 1,048,575 data rows
# ============================================================


def _print(*a):
    print(*a)


def _norm(h):
    return re.sub(r"\s+", " ", str(h).strip().lower()) if h is not None else ""


def _clean(v):
    """Cell -> stripped text ('' for blank)."""
    if v is None:
        return ""
    if isinstance(v, float) and v.is_integer():
        return str(int(v))
    return str(v).strip()


def _blank_to_none(v):
    if v is None:
        return None
    if isinstance(v, str):
        v = v.strip()
        return v if v else None
    return v


def parse_priority(v):
    """Numbers stay numbers; '1/3' (written by the forward script) becomes 1/3."""
    v = _blank_to_none(v)
    if v is None or isinstance(v, (int, float)):
        return v
    s = str(v).strip().replace(",", ".")
    m = re.fullmatch(r"(\d+(?:\.\d+)?)\s*/\s*(\d+(?:\.\d+)?)", s)
    if m and float(m.group(2)) != 0:
        return float(m.group(1)) / float(m.group(2))
    try:
        return float(s)
    except ValueError:
        return v


def id_value(s):
    """'17' -> 17 (numeric cell), anything else stays text."""
    if s is None or s == "":
        return None
    return int(s) if re.fullmatch(r"\d+", s) and not (len(s) > 1 and s.startswith("0")) else s


# ---- reading the flat list ---------------------------------------------------
def read_flat(path, sheet=None):
    """Returns (rows, headers, meta).  rows = list of dict header->value."""
    wb = load_workbook(path, data_only=True)
    meta = None
    if META_SHEET in wb.sheetnames:
        try:
            meta = json.loads(wb[META_SHEET]["A1"].value)
        except Exception:
            meta = None
    if sheet is not None:
        ws = wb[sheet]
    elif "BOM" in wb.sheetnames:
        ws = wb["BOM"]
    else:
        ws = wb.worksheets[0]

    header_row = None
    for r_idx, row in enumerate(ws.iter_rows(min_row=1, max_row=15, values_only=True), 1):
        names = {_norm(v) for v in row}
        if "bom (of)" in names and "pn um" in names:
            header_row = r_idx
            headers = [str(v).strip() if v is not None else "" for v in row]
            break
    if header_row is None:
        raise ValueError(
            "Could not find a header row containing 'BOM (of)' and 'PN UM' "
            "(is this the BOM sheet written by bom_forward.py?)")

    rows = []
    for row in ws.iter_rows(min_row=header_row + 1, values_only=True):
        if row is None or all(_clean(v) == "" for v in row):
            continue
        rows.append({headers[i]: row[i] for i in range(min(len(headers), len(row))) if headers[i]})
    return rows, [h for h in headers if h], meta


def flat_columns(headers, meta):
    """Classify the flat headers.  Returns a dict of header names / extras."""
    by_norm = {_norm(h): h for h in headers}
    cols = {
        "bom": by_norm.get(_norm(H_BOM)), "bom_id": by_norm.get(_norm(H_BOM_ID)),
        "pn": by_norm.get(_norm(H_PN)), "group": by_norm.get(_norm(H_GROUP)),
        "prio": by_norm.get(_norm(H_PRIO)), "qty": by_norm.get(_norm(H_QTY)),
        "child_id": by_norm.get(_norm(H_CHILD_ID)),
    }
    fixed = {v for v in cols.values() if v}
    hmap = (meta or {}).get("header_map", {})
    hmap_norm = {_norm(k): v for k, v in hmap.items()}
    extras = []                                    # (flat header, original column name)
    for h in headers:
        if h in fixed or is_bom_header(h):
            continue
        orig = hmap_norm.get(_norm(h))
        if orig is None:
            orig = h[:-3] if h.upper().endswith(" UM") else h
        extras.append((h, orig))
    cols["extras"] = extras
    # "<col>-BOM (of)" = attributes of the BOM owner (used for sections without a product row)
    cols["parent_attrs"] = [(h, h[:-len(BOM_SUFFIX)]) for h in headers
                            if h.lower().endswith(BOM_SUFFIX.lower()) and h not in fixed]
    return cols


def build_boms(rows, cols, issues):
    """Group the flat rows into products and one child list per BOM owner."""
    roots, boms, ids, owners, owner_attrs = [], {}, {}, [], {}
    for r in rows:
        bom = _clean(r.get(cols["bom"]))
        pn = _clean(r.get(cols["pn"]))
        if not pn:
            continue
        rec = {
            "pn": pn,
            "qty": _blank_to_none(r.get(cols["qty"])) if cols["qty"] else None,
            "prio": parse_priority(r.get(cols["prio"])) if cols["prio"] else None,
            "group": _clean(r.get(cols["group"])) if cols["group"] else "",
            "child_id": _clean(r.get(cols["child_id"])) if cols["child_id"] else "",
            "extras": {orig: _blank_to_none(r.get(h)) for h, orig in cols["extras"]},
        }
        if not bom:
            roots.append(rec)
            continue
        if bom not in boms:
            boms[bom] = []
            owners.append(bom)
            owner_attrs[bom] = {orig: _blank_to_none(r.get(h)) for h, orig in cols["parent_attrs"]}
        if cols["bom_id"] and bom not in ids:
            parts = [p.strip() for p in _clean(r.get(cols["bom_id"])).split(",") if p.strip()]
            if parts:
                ids[bom] = parts
        boms[bom].append(rec)
    # "X" is the leaf marker only when it is the ONLY row of a section; next to other children
    # it is an ordinary part that happens to be called X.
    for bom, kids in boms.items():
        if len(kids) == 1 and kids[0]["pn"].upper() == "X":
            boms[bom] = []
    return roots, boms, ids, owners, owner_attrs

# ---- exploding ---------------------------------------------------------------
class ExplosionTooLarge(Exception):
    pass


def explode(roots, boms, owners, owner_attrs, collapse, max_rows, issues):
    """Depth-first explosion.  Returns a list of (level, record, parent_pn)."""
    out = []
    expanded = set()
    reached = set()

    def run(root_rec):
        stack = [(root_rec, 0, None)]
        path = []
        while stack:
            rec, level, parent = stack.pop()
            del path[level:]
            pn = rec["pn"]
            is_cycle = pn in path
            out.append((level, rec, parent))
            if len(out) > max_rows:
                raise ExplosionTooLarge(len(out))
            reached.add(pn)
            path.append(pn)
            if is_cycle:
                issues.append(f"Cycle: '{pn}' is inside its own BOM (path {' > '.join(path)}). "
                              f"It is listed but not expanded again.")
                continue
            kids = boms.get(pn)
            if kids and not (collapse and pn in expanded):
                expanded.add(pn)
                for k in reversed(kids):
                    stack.append((k, level + 1, pn))

    for r in roots:
        run(r)

    while True:                                   # BOM sections nobody reaches
        pending = [o for o in owners if o not in reached]
        if not pending:
            break
        used_by_pending = {c["pn"] for o in pending for c in boms[o]}
        tops = [o for o in pending if o not in used_by_pending]
        start = tops[0] if tops else pending[0]
        why = "no product row and not used by any other BOM" if tops else "part of a cycle"
        issues.append(f"BOM section '{start}' is not reachable from any product row ({why}); "
                      f"added as a separate tree starting at level 0.")
        run({"pn": start, "qty": None, "prio": None, "group": "", "child_id": "",
             "extras": dict(owner_attrs.get(start, {}))})
    return out


def assign_ids(occurrences, ids, issues):
    """Hand the ids of 'ID BOM (of)' to the occurrences of every PN (explicit ids first)."""
    pools = {pn: deque(v) for pn, v in ids.items()}
    for _, rec, _ in occurrences:
        e = rec["child_id"]
        if e:
            pool = pools.get(rec["pn"])
            if pool and e in pool:
                pool.remove(e)
    result, short = [], defaultdict(int)
    for _, rec, _ in occurrences:
        e = rec["child_id"]
        if e:
            result.append(e)
            continue
        pool = pools.get(rec["pn"])
        if pool:
            result.append(pool.popleft())
        else:
            result.append("")
            short[rec["pn"]] += 1
    leftover = {pn: list(p) for pn, p in pools.items() if p}
    if short:
        sample = ", ".join(f"{pn} (x{n})" for pn, n in list(short.items())[:8])
        issues.append(f"ID: {sum(short.values())} row(s) of {len(short)} PN(s) have no id left "
                      f"(more occurrences than ids): {sample}{' ...' if len(short) > 8 else ''}. "
                      f"Expected when rows were added by hand; otherwise try --collapse-repeats "
                      f"(the original may have listed repeated assemblies without their content).")
    if leftover:
        sample = ", ".join(f"{pn} ({len(v)})" for pn, v in list(leftover.items())[:8])
        issues.append(f"ID: {sum(len(v) for v in leftover.values())} id(s) of {len(leftover)} PN(s) were not used "
                      f"(fewer occurrences than ids): {sample}{' ...' if len(leftover) > 8 else ''}.")
    return result, sum(short.values()), sum(len(v) for v in leftover.values())


def group_members(boms):
    gm = {}
    for parent, kids in boms.items():
        d = defaultdict(list)
        for k in kids:
            if k["group"] and k["pn"] not in d[k["group"]]:
                d[k["group"]].append(k["pn"])
        for g, members in d.items():
            gm[(parent, g)] = members
    return gm


# ---- layout ------------------------------------------------------------------
def _next_rel_names(rel_names, want):
    m = REL_RE.match(rel_names[-1]) if rel_names else None
    prefix = re.sub(r"\d+$", "", rel_names[-1]) if m else "R"
    n = int(m.group(1)) if m else 0
    names = list(rel_names)
    while len(names) < want:
        n += 1
        names.append(f"{prefix}{n}")
    return names


def build_layout(meta, cols, n_rel):
    """List of (kind, name, index) in output order.  kind: level pn id rel prio qty extra"""
    layout, notes = [], []
    extras_by_orig = {orig: h for h, orig in cols["extras"]}
    if meta and meta.get("input_columns"):
        core = meta.get("core", {})
        rel_names = list(core.get("rels") or [])
        all_rel = _next_rel_names(rel_names, max(n_rel, len(rel_names)))
        used = set()
        for name in meta["input_columns"]:
            if name == core.get("level"):
                layout.append(("level", name, None))
            elif name == core.get("pn"):
                layout.append(("pn", name, None))
            elif name == core.get("id"):
                layout.append(("id", name, None))
            elif core.get("priority") and name == core["priority"]:
                if cols["prio"]:
                    layout.append(("prio", name, None))
            elif core.get("qty") and name == core["qty"]:
                if cols["qty"]:
                    layout.append(("qty", name, None))
            elif name in rel_names:
                if name == rel_names[-1]:             # extra relation columns follow the last one
                    for i, nm in enumerate(all_rel):
                        if i >= rel_names.index(name):
                            layout.append(("rel", nm, i))
                else:
                    layout.append(("rel", name, rel_names.index(name)))
            elif name in extras_by_orig:
                layout.append(("extra", name, None))
                used.add(name)
            else:
                notes.append(name)
        for h, orig in cols["extras"]:
            if orig not in used:
                layout.append(("extra", orig, None))
        if n_rel and not rel_names:
            for i, nm in enumerate(_next_rel_names([], n_rel)):
                layout.append(("rel", nm, i))
        if notes:
            notes = [f"Columns of the original file that are not in the flat list were left out: {notes}"]
    else:
        layout = [("level", "Level", None), ("pn", "PN", None), ("id", "ID", None)]
        for i, nm in enumerate(_next_rel_names([], max(3, n_rel))):
            layout.append(("rel", nm, i))
        if cols["prio"]:
            layout.append(("prio", "Priority", None))
        if cols["qty"]:
            layout.append(("qty", "QTY", None))
        for h, orig in cols["extras"]:
            layout.append(("extra", orig, None))
    return layout, notes

# ---- whole conversion --------------------------------------------------------
def rebuild_rows(rows, headers, meta, collapse=False, max_rows=MAX_ROWS):
    """Flat rows -> (header_names, table, layout, issues, stats)."""
    issues = []
    cols = flat_columns(headers, meta)
    if not cols["bom"] or not cols["pn"]:
        raise ValueError("The sheet needs the columns 'BOM (of)' and 'PN UM'.")
    roots, boms, ids, owners, owner_attrs = build_boms(rows, cols, issues)
    if not roots and not boms:
        raise ValueError("The BOM sheet has no data rows.")
    if not roots:
        issues.append("No product row (empty 'BOM (of)') found - the top-level BOMs were used as products.")

    try:
        occ = explode(roots, boms, owners, owner_attrs, collapse, max_rows, issues)
    except ExplosionTooLarge:
        raise ValueError(
            f"The exploded hierarchy would be longer than {max_rows:,} rows. "
            f"Use --collapse-repeats (list a repeated assembly's content only once) "
            f"or raise --max-rows.") from None

    id_list, id_short, id_left = assign_ids(occ, ids, issues)
    gm = group_members(boms)
    n_rel = max([len(m) - 1 for m in gm.values()] + [0])
    layout, notes = build_layout(meta, cols, n_rel)
    issues.extend(notes)

    table = []
    for i, (level, rec, parent) in enumerate(occ):
        members = gm.get((parent, rec["group"]), []) if parent is not None and rec["group"] else []
        rels = [m for m in members if m != rec["pn"]]
        row = []
        for kind, name, idx in layout:
            if kind == "level":
                row.append(level)
            elif kind == "pn":
                row.append(rec["pn"])
            elif kind == "id":
                row.append(id_value(id_list[i]))
            elif kind == "rel":
                row.append(rels[idx] if idx < len(rels) else None)
            elif kind == "prio":
                row.append(rec["prio"])
            elif kind == "qty":
                row.append(rec["qty"])
            else:
                row.append(rec["extras"].get(name))
        table.append(row)

    stats = {"rows": len(table), "products": len(roots), "bom_sections": len(boms),
             "id_missing": id_short, "id_unused": id_left, "issues": len(issues),
             "max_level": max((o[0] for o in occ), default=0)}
    return [name for _, name, _ in layout], table, layout, issues, stats


def write_hierarchy_xlsx(headers, table, layout, issues, out_path):
    wb = Workbook()
    ws = wb.active
    ws.title = "Hierarchy"
    head_fill = PatternFill(start_color="2F5496", end_color="2F5496", fill_type="solid")
    head_font = Font(bold=True, color="FFFFFF")
    center = Alignment(horizontal="center", vertical="center")
    thin = Side(style="thin", color="BFBFBF")
    border = Border(left=thin, right=thin, top=thin, bottom=thin)

    for c_idx, h in enumerate(headers, 1):
        cell = ws.cell(row=1, column=c_idx, value=h)
        cell.fill, cell.font, cell.alignment, cell.border = head_fill, head_font, center, border

    kinds = [k for k, _, _ in layout]
    pn_col = kinds.index("pn") if "pn" in kinds else None
    lv_col = kinds.index("level") if "level" in kinds else None
    indents = {}
    for r_idx, row in enumerate(table, 2):
        for c_idx, val in enumerate(row, 1):
            ws.cell(row=r_idx, column=c_idx, value=val)
        if pn_col is not None and lv_col is not None:
            lvl = min(int(row[lv_col] or 0), 12)
            al = indents.get(lvl)
            if al is None:
                al = indents[lvl] = Alignment(indent=lvl)
            ws.cell(row=r_idx, column=pn_col + 1).alignment = al

    for c_idx in range(1, len(headers) + 1):
        ws.column_dimensions[get_column_letter(c_idx)].width = 16
    ws.freeze_panes = "A2"
    if table:
        ws.auto_filter.ref = f"A1:{get_column_letter(len(headers))}{1 + len(table)}"

    ws2 = wb.create_sheet("Issues")
    ws2["A1"] = "Notes / Warnings"
    ws2["A1"].font = Font(bold=True, size=11)
    if not issues:
        ws2["A3"] = "Nothing to report."
        ws2["A3"].font = Font(color="006600", size=9)
    else:
        ws2["A3"] = f"{len(issues)} note(s):"
        ws2["A3"].font = Font(bold=True, color="CC0000", size=9)
        for idx, msg in enumerate(issues, 4):
            ws2.cell(row=idx, column=1, value=msg).font = Font(size=9)
    ws2.column_dimensions["A"].width = 120
    wb.save(out_path)


def rebuild_file(input_path, output_path, collapse=False, max_rows=MAX_ROWS, sheet=None, log=_print):
    log(f"Reading: {input_path}")
    rows, headers, meta = read_flat(input_path, sheet)
    log(f"Loaded {len(rows)} BOM rows" + ("  (column layout restored from the _meta sheet)" if meta else
                                         "  (no _meta sheet: default column layout)"))
    names, table, layout, issues, stats = rebuild_rows(rows, headers, meta, collapse, max_rows)
    if issues:
        log(f"\n=== {len(issues)} NOTE(S) ===")
        for msg in issues[:50]:
            log(" ! " + msg)
        if len(issues) > 50:
            log(f" ... and {len(issues) - 50} more (see the Issues sheet)")
    write_hierarchy_xlsx(names, table, layout, issues, output_path)
    if any(_norm(h) == _norm(H_CHILD_ID) for h in headers):
        log("IDs: taken from the 'ID UM' column (exact); the rest from 'ID BOM (of)'.")
    else:
        log("IDs: handed out per PN from 'ID BOM (of)', lowest first, in the order the PN occurs "
            "(run the forward step with the 'ID UM' column for exact ids).")
    log(f"Wrote {stats['rows']} rows ({stats['products']} product(s), deepest level {stats['max_level']}) -> {output_path}")
    return {"headers": names, "table": table, "issues": issues, "stats": stats}


# ---- command line ------------------------------------------------------------
def main(argv=None):
    ap = argparse.ArgumentParser(description="BOM list per PN -> exploded Level/PN/ID hierarchy")
    ap.add_argument("-i", "--input", help=f"flat BOM xlsx (default {INPUT_FILE})")
    ap.add_argument("-o", "--output", help=f"hierarchy xlsx to write (default {OUTPUT_FILE})")
    ap.add_argument("--sheet", help="sheet to read (default: 'BOM' or the first sheet)")
    ap.add_argument("--collapse-repeats", action="store_true",
                    help="list the content of a repeated assembly only the first time")
    ap.add_argument("--max-rows", type=int, default=MAX_ROWS)
    ap.add_argument("--ui", action="store_true", help="open the optional window")
    args = ap.parse_args(argv)

    if args.ui:
        try:
            import bom_ui
        except ImportError as e:
            print(f"Cannot start the UI: {e}")
            return 1
        return bom_ui.main(initial_tab="reverse")

    try:
        rebuild_file(args.input or INPUT_FILE, args.output or OUTPUT_FILE,
                     collapse=args.collapse_repeats or COLLAPSE_REPEATS,
                     max_rows=args.max_rows, sheet=args.sheet)
    except (ValueError, OSError, KeyError) as e:
        print(f"ERROR: {e}")
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())

