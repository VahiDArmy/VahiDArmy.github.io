#!/usr/bin/env python3
"""
Checks you can run on your OWN (private) files.  Nothing is uploaded anywhere, and by
default only counts, row numbers and column names are printed - never cell values -
so the result can be shared safely.  Add --show-values to see the values as well.

  python bom_check.py compare OLD.xlsx NEW.xlsx
        Compare two BOM lists, e.g. the output of your old script (g04071405.py)
        with the output of bom_forward.py --legacy (should be IDENTICAL) or without
        --legacy (differences = rows the old duplicate handling got wrong).

  python bom_check.py roundtrip BOM_output.xlsx
        BOM list -> hierarchy -> BOM list again.  Must come back identical.

  python bom_check.py full input.xlsx
        Everything on your original hierarchy file: forward conversion, effect of the
        duplicate-assembly fix, round trip, and how close the rebuilt hierarchy is
        to your original (ids, PNs, parents, depth).

Options:  --limit N (rows listed per finding, default 15)   --show-values
          --collapse-repeats (rebuild with each repeated assembly's content only once)
          --keep FOLDER  (keep the intermediate files there; default: deleted)
"""

import argparse
import os
import sys
import tempfile
from collections import Counter, defaultdict

from openpyxl import load_workbook

import bom_forward as F
import bom_reverse as R

QUIET = lambda *a: None


# ---- reading / normalising ---------------------------------------------------
def _norm(v):
    if v is None:
        return ""
    if isinstance(v, float):
        if v == int(v):
            return int(v)
        return round(v, 9)
    if isinstance(v, str):
        return v.strip()
    return v


def read_sheet(path, sheet="BOM"):
    wb = load_workbook(path, data_only=True)
    ws = wb[sheet] if sheet in wb.sheetnames else wb.worksheets[0]
    rows = [[_norm(v) for v in r] for r in ws.iter_rows(values_only=True)]
    while rows and all(v == "" for v in rows[-1]):
        rows.pop()
    return rows


def _col(head, name):
    low = [str(h).strip().lower() for h in head]
    return low.index(name.lower()) if name.lower() in low else None


def canonical(head, body):
    """Group numbers replaced by the members of the group, so numbering/order do not matter."""
    ib, ig, ip = _col(head, "BOM (of)"), _col(head, "Group UM"), _col(head, "PN UM")
    members = defaultdict(set)
    if None not in (ib, ig, ip):
        for r in body:
            if r[ig] != "":
                members[(r[ib], r[ig])].add(r[ip])
    out = []
    for r in body:
        r = list(r)
        if None not in (ib, ig, ip) and r[ig] != "":
            r[ig] = tuple(sorted(members[(r[ib], r[ig])]))
        out.append(tuple(r))
    return out


def _fmt_rows(nums, limit):
    nums = list(nums)
    shown = ", ".join(str(n) for n in nums[:limit])
    return shown + (f" ... (+{len(nums) - limit} more)" if len(nums) > limit else "")


# ---- comparing two BOM lists ---------------------------------------------------
def compare_flat(path_a, path_b, label_a="A", label_b="B", limit=15, show_values=False, out=print):
    """Returns True when strictly identical.  Prints a short report."""
    A, B = read_sheet(path_a), read_sheet(path_b)
    ha, hb = A[0], B[0]
    ba, bb = A[1:], B[1:]
    out(f"  rows: {label_a} = {len(ba)}, {label_b} = {len(bb)}")
    if ha != hb:
        only_a = [h for h in ha if h not in hb]
        only_b = [h for h in hb if h not in ha]
        out(f"  columns differ: only in {label_a}: {only_a or '-'}; only in {label_b}: {only_b or '-'}"
            + ("" if (only_a or only_b) else "; same columns but in a different order"))
    strict = (ha == hb and ba == bb)
    if strict:
        out("  STRICT   : IDENTICAL (every cell, same order)")
    elif ha == hb and len(ba) == len(bb):
        cols, rows = Counter(), []
        for i, (x, y) in enumerate(zip(ba, bb), 2):
            d = [ha[j] for j in range(len(ha)) if x[j] != y[j]]
            if d:
                rows.append(i)
                cols.update(d)
        out(f"  STRICT   : differs in {len(rows)} row(s), columns: {dict(cols)}")
        out(f"             first rows (sheet row numbers): {_fmt_rows(rows, limit)}")
    else:
        out("  STRICT   : not comparable cell-by-cell (different columns or number of rows)")

    common = [h for h in ha if h in hb]
    ia = [ha.index(h) for h in common]
    ib_ = [hb.index(h) for h in common]
    ca = canonical(common, [[r[i] for i in ia] for r in ba])
    cb = canonical(common, [[r[i] for i in ib_] for r in bb])
    ma, mb = Counter(ca), Counter(cb)
    only_a, only_b = ma - mb, mb - ma
    if not only_a and not only_b:
        out("  CONTENT  : identical as a set of rows (order and group numbers ignored)")
    else:
        na, nb = sum(only_a.values()), sum(only_b.values())
        out(f"  CONTENT  : {sum((ma & mb).values())} rows in both, {na} only in {label_a}, {nb} only in {label_b}")
        for lab, only, rows in ((label_a, only_a, ca), (label_b, only_b, cb)):
            if only:
                pos = [i for i, t in enumerate(rows, 2) if only.get(t)]
                out(f"             rows only in {lab} (sheet row numbers): {_fmt_rows(pos, limit)}")
                if show_values:
                    for i in pos[:limit]:
                        out(f"               row {i}: {rows[i - 2]}")
    return strict


# ---- the three commands --------------------------------------------------------
def cmd_compare(a, b, limit, show_values):
    print(f"Comparing\n  A = {a}\n  B = {b}")
    ok = compare_flat(a, b, "A", "B", limit, show_values)
    ia, ib = len(read_sheet(a, "Issues")), len(read_sheet(b, "Issues"))
    print(f"  Issues sheet lines: A = {ia}, B = {ib}")
    return 0 if ok else 1


def cmd_roundtrip(flat, collapse, limit, show_values, keep):
    with _workdir(keep) as w:
        h2, f2 = os.path.join(w, "rebuilt_hierarchy.xlsx"), os.path.join(w, "bom_again.xlsx")
        print(f"BOM list -> hierarchy -> BOM list   ({flat})")
        rr = R.rebuild_file(flat, h2, collapse=collapse, log=QUIET)
        st = rr["stats"]
        print(f"  rebuilt hierarchy: {st['rows']} rows, {st['products']} product(s), deepest level {st['max_level']}")
        print(f"  ids: {st['id_missing']} row(s) without id, {st['id_unused']} id(s) unused;  notes: {st['issues']}")
        F.convert_file(h2, f2, embed_meta=False, log=QUIET)
        ok = compare_flat(flat, f2, "original", "after round trip", limit, show_values)
    return 0 if ok else 1


def _hier_structure(path):
    data, *_ = F.load_from_excel(path, [], log=QUIET)
    stack, rows = [], []
    for r in data:
        while stack and stack[-1][0] >= r["level"]:
            stack.pop()
        rows.append({"pn": r["pn"], "id": str(r["id"]), "depth": len(stack),
                     "parent": stack[-1][1] if stack else None, "src": r["src_row"]})
        stack.append((r["level"], r["pn"]))
    return rows


def cmd_full(hier, collapse, limit, show_values, keep):
    with _workdir(keep) as w:
        p = lambda n: os.path.join(w, n)
        print(f"1) Forward conversion of {hier}")
        res = F.convert_file(hier, p("bom_new.xlsx"), log=QUIET)
        st = res["stats"]
        cats = Counter()
        for m in res["issues"]:
            cats["inconsistent BOM" if m.startswith("Inconsistent") else
                 "recursive" if m.startswith("Recursive") else
                 "ignored children" if "were ignored" in m else "group/priority/other"] += 1
        print(f"   output rows {st['rows']}: {st['roots']} product row(s), {st['assemblies']} assemblies, "
              f"{st['leaves']} leaf (X) rows")
        print(f"   repeated assemblies kept in their parent's BOM: {st['repeated_assemblies_kept']}")
        print(f"   issues: {len(res['issues'])}  {dict(cats) if cats else ''}")

        print("\n2) New handling vs old handling (bom_forward.py --legacy = g04071405.py)")
        F.convert_file(hier, p("bom_legacy.xlsx"), legacy=True, embed_meta=False, log=QUIET)
        same = compare_flat(p("bom_legacy.xlsx"), p("bom_new.xlsx"), "old", "new", limit, show_values)
        if same:
            print("   -> no difference: the old logic handled your file correctly.")
        else:
            print("   -> rows 'only in old' are wrong/misplaced entries of the old logic, rows 'only in new' are what it missed.")

        print("\n3) Round trip: forward -> reverse -> forward")
        rr = R.rebuild_file(p("bom_new.xlsx"), p("rebuilt.xlsx"), collapse=collapse, log=QUIET)
        F.convert_file(p("rebuilt.xlsx"), p("bom_again.xlsx"), embed_meta=False, log=QUIET)
        ok = compare_flat(p("bom_new.xlsx"), p("bom_again.xlsx"), "first", "again", limit, show_values)

        print("\n4) Rebuilt hierarchy vs your original file")
        H, H2 = _hier_structure(hier), _hier_structure(p("rebuilt.xlsx"))
        print(f"   rows: original = {len(H)}, rebuilt = {len(H2)}")
        by_id = {}
        dup_ids = 0
        for r in H:
            if r["id"] in by_id:
                dup_ids += 1
            by_id[r["id"]] = r
        by_id2 = {r["id"]: r for r in H2 if r["id"]}
        both = [i for i in by_id if i in by_id2]
        print(f"   ids: {len(both)} in both, {len([i for i in by_id if i not in by_id2])} only in the original, "
              f"{len([i for i in by_id2 if i not in by_id])} only in the rebuilt file"
              + (f"  ({dup_ids} duplicate ids in the original)" if dup_ids else ""))
        if both:
            same_pn = [i for i in both if by_id[i]["pn"] == by_id2[i]["pn"]]
            same_par = [i for i in both if by_id[i]["parent"] == by_id2[i]["parent"]]
            same_dep = [i for i in both if by_id[i]["depth"] == by_id2[i]["depth"]]
            print(f"   same id -> same PN: {len(same_pn)} / {len(both)}   same parent PN: {len(same_par)} / {len(both)}"
                  f"   same depth: {len(same_dep)} / {len(both)}")
            ok_pn = set(same_pn)
            bad = [by_id[i]["src"] for i in both if i not in ok_pn]
            if bad:
                print(f"   original rows whose id got another PN (sheet row numbers): {_fmt_rows(bad, limit)}")
        print(f"   rebuild notes: {len(rr['issues'])}  (ids missing {rr['stats']['id_missing']}, unused {rr['stats']['id_unused']})")
        if len(H2) > len(H):
            print("   -> the rebuilt file is longer: your original probably lists repeated assemblies WITHOUT their "
                  "content. Try --collapse-repeats.")
        elif len(H2) < len(H):
            print("   -> the rebuilt file is shorter: rows inside repeated assemblies that differ from the first "
                  "definition (see the 'Inconsistent BOM' issues) or blank/invalid rows are not rebuilt.")
    return 0 if ok else 1


class _workdir:
    def __init__(self, keep):
        self.keep = keep

    def __enter__(self):
        if self.keep:
            os.makedirs(self.keep, exist_ok=True)
            self.path = self.keep
            self.tmp = None
        else:
            self.tmp = tempfile.TemporaryDirectory(prefix="bom_check_")
            self.path = self.tmp.name
        return self.path

    def __exit__(self, *exc):
        if self.tmp:
            self.tmp.cleanup()
        else:
            print(f"\n(intermediate files kept in {self.path})")


def main(argv=None):
    ap = argparse.ArgumentParser(description="Privacy-preserving checks for the BOM converters")
    sub = ap.add_subparsers(dest="cmd", required=True)
    for name in ("compare", "roundtrip", "full"):
        sp = sub.add_parser(name)
        if name == "compare":
            sp.add_argument("a")
            sp.add_argument("b")
        else:
            sp.add_argument("file")
            sp.add_argument("--collapse-repeats", action="store_true")
            sp.add_argument("--keep", metavar="FOLDER")
        sp.add_argument("--limit", type=int, default=15)
        sp.add_argument("--show-values", action="store_true")
    args = ap.parse_args(argv)
    try:
        if args.cmd == "compare":
            return cmd_compare(args.a, args.b, args.limit, args.show_values)
        if args.cmd == "roundtrip":
            return cmd_roundtrip(args.file, args.collapse_repeats, args.limit, args.show_values, args.keep)
        return cmd_full(args.file, args.collapse_repeats, args.limit, args.show_values, args.keep)
    except (ValueError, OSError, KeyError) as e:
        print(f"ERROR: {e}")
        return 2


if __name__ == "__main__":
    sys.exit(main())
