#!/usr/bin/env python3
"""
Optional window for the BOM converters (forward and reverse).

    python bom_ui.py
    python bom_forward.py --ui
    python bom_reverse.py --ui

Needs nothing but Python's own tkinter.  Nothing here changes how the scripts behave when
you run them the usual way.

Forward tab, after the input file is read you can choose
  * which columns are PARENT columns  (= BOM_COLUMNS in bom_forward.py)
  * which columns are written and in which order (= OUTPUT_COLUMN_ORDER)
The script's own constants are the defaults.  What you choose is saved in
bom_converter_settings.json (next to the scripts) and prefilled the next time.
"""

import os
import queue
import subprocess
import sys
import threading
import traceback

try:
    import tkinter as tk
    from tkinter import filedialog, messagebox, ttk
    TK_ERROR = None
except ImportError as _e:                 # tkinter missing: the module still imports, main() explains
    TK_ERROR = str(_e)

    class _Stub:
        Frame = Tk = object

    tk = ttk = _Stub()
    filedialog = messagebox = None

import bom_forward as F
import bom_reverse as R

ID_UM_HINT = "ID UM = id of each child row (optional; lets the reverse converter restore exact ids)"


# ============================================================================
# Pure logic (no tkinter) - the window only displays this
# ============================================================================
def initial_forward_state(extras, saved=None):
    """
    Which BOM columns / output columns to show after a file was read.
    saved = the 'forward' section of the settings file (or the current window state).
    Returns dict(bom, chosen, available, notes).
    """
    saved = saved or {}
    notes = []
    if saved.get("bom_columns") is not None:
        want_bom, src = saved["bom_columns"], "saved choice"
    else:
        want_bom, src = F.BOM_COLUMNS, "script default"
    lowmap = {e.lower(): e for e in extras}
    bom = []
    for b in want_bom:
        real = lowmap.get(str(b).strip().lower())
        if real is None:
            notes.append(f"Parent column '{b}' ({src}) is not in this file - skipped")
        elif real not in bom:
            bom.append(real)

    if saved.get("output_order"):
        chosen, missing, new = F.resolve_saved(saved["output_order"], saved.get("output_excluded", []),
                                               bom, extras)
        for m in missing:
            notes.append(f"Output column '{m}' (saved choice) is not available for this file - skipped")
        if new:
            notes.append("New in this file, added at the end of the output: " + ", ".join(new))
    else:
        chosen, missing = F.resolve_output_columns(F.OUTPUT_COLUMN_ORDER, bom, extras,
                                                   append_rest=True, strict=True)
        if missing:
            notes.append("Script-default output columns not in this file: " + ", ".join(missing))
    have = {c.lower() for c in chosen}
    available = [k for k in F.candidate_keys(bom, extras) if k.lower() not in have]
    return {"bom": bom, "chosen": chosen, "available": available, "notes": notes}


def change_bom(chosen, available, old_bom, new_bom):
    """The parent-column choice changed: add/remove the '<col>-BOM (of)' output columns."""
    chosen, available = list(chosen), list(available)
    old_l, new_l = {b.lower() for b in old_bom}, {b.lower() for b in new_bom}
    for b in old_bom:
        if b.lower() not in new_l:
            key = (b + F.BOM_SUFFIX).lower()
            chosen = [c for c in chosen if c.lower() != key]
            available = [c for c in available if c.lower() != key]
    for b in new_bom:
        if b.lower() not in old_l:
            chosen.append(b + F.BOM_SUFFIX)
    return chosen, available


def forward_settings(bom, chosen, extras, legacy, meta, in_path, out_path):
    """What gets written to the settings file."""
    have = {c.lower() for c in chosen}
    excluded = [k for k in F.candidate_keys(bom, extras)
                if k.lower() not in have and k != F.H_CHILD_ID]
    return {"bom_columns": list(bom), "output_order": list(chosen), "output_excluded": excluded,
            "legacy": bool(legacy), "embed_meta": bool(meta),
            "last_input": in_path, "last_output": out_path}


def default_output_path(in_path, name):
    folder = os.path.dirname(os.path.abspath(in_path)) if in_path else os.getcwd()
    return os.path.join(folder, name)


def open_folder(path):
    folder = os.path.dirname(os.path.abspath(path))
    try:
        if sys.platform.startswith("win"):
            os.startfile(folder)                                   # type: ignore[attr-defined]
        elif sys.platform == "darwin":
            subprocess.Popen(["open", folder])
        else:
            subprocess.Popen(["xdg-open", folder])
    except Exception:
        pass

# ============================================================================
# Widgets
# ============================================================================
def _scrolled_listbox(parent, selectmode, height):
    lb = tk.Listbox(parent, selectmode=selectmode, exportselection=False, height=height,
                    activestyle="none")
    sb = ttk.Scrollbar(parent, orient="vertical", command=lb.yview)
    lb.configure(yscrollcommand=sb.set)
    return lb, sb


class PickMany(ttk.Frame):
    """List where the selected rows are the chosen ones (BOM_COLUMNS)."""

    def __init__(self, master, on_change=None, height=12):
        super().__init__(master)
        self._items, self._on_change = [], on_change
        self.lb, sb = _scrolled_listbox(self, "multiple", height)      # click toggles
        self.lb.grid(row=0, column=0, sticky="nsew")
        sb.grid(row=0, column=1, sticky="ns")
        self.columnconfigure(0, weight=1)
        self.rowconfigure(0, weight=1)
        self.lb.bind("<<ListboxSelect>>", lambda _e: self._on_change and self._on_change())

    def set_items(self, items, selected):
        self._items = list(items)
        self.lb.delete(0, "end")
        for it in self._items:
            self.lb.insert("end", it)
        want = {s.lower() for s in selected}
        for i, it in enumerate(self._items):
            if it.lower() in want:
                self.lb.selection_set(i)

    def get_selected(self):
        return [self._items[i] for i in self.lb.curselection()]


class OrderPicker(ttk.Frame):
    """Two lists (available / output order) with Add, Remove, Up, Down."""

    def __init__(self, master, on_change=None, height=12):
        super().__init__(master)
        self._on_change = on_change
        ttk.Label(self, text="Available").grid(row=0, column=0, sticky="w")
        ttk.Label(self, text="Output order (top = first column)").grid(row=0, column=2, sticky="w")
        self.avail, sb1 = _scrolled_listbox(self, "extended", height)
        self.chosen, sb2 = _scrolled_listbox(self, "extended", height)
        self.avail.grid(row=1, column=0, sticky="nsew")
        sb1.grid(row=1, column=0, sticky="nse")
        self.chosen.grid(row=1, column=2, sticky="nsew")
        sb2.grid(row=1, column=2, sticky="nse")
        mid = ttk.Frame(self)
        mid.grid(row=1, column=1, padx=4)
        ttk.Button(mid, text="Add  >", width=10, command=self.add).pack(pady=2)
        ttk.Button(mid, text="<  Remove", width=10, command=self.remove).pack(pady=2)
        side = ttk.Frame(self)
        side.grid(row=1, column=3, padx=(4, 0))
        ttk.Button(side, text="Up", width=8, command=lambda: self.move(-1)).pack(pady=2)
        ttk.Button(side, text="Down", width=8, command=lambda: self.move(+1)).pack(pady=2)
        for c in (0, 2):
            self.columnconfigure(c, weight=1)
        self.rowconfigure(1, weight=1)
        self.avail.bind("<Double-Button-1>", lambda _e: self.add())
        self.chosen.bind("<Double-Button-1>", lambda _e: self.remove())

    @staticmethod
    def _fill(lb, items, marks=None):
        lb.delete(0, "end")
        for it in items:
            lb.insert("end", it)
        for i in (marks or []):
            lb.selection_set(i)

    def set_items(self, available, chosen):
        self._fill(self.avail, available)
        self._fill(self.chosen, chosen)

    def get_chosen(self):
        return list(self.chosen.get(0, "end"))

    def get_available(self):
        return list(self.avail.get(0, "end"))

    def _changed(self):
        if self._on_change:
            self._on_change()

    def add(self):
        sel = list(self.avail.curselection())
        if not sel:
            return
        a, c = self.get_available(), self.get_chosen()
        moved = [a[i] for i in sel]
        a = [x for i, x in enumerate(a) if i not in sel]
        pos = self.chosen.curselection()
        at = (max(pos) + 1) if pos else len(c)
        c[at:at] = moved
        self._fill(self.avail, a)
        self._fill(self.chosen, c, range(at, at + len(moved)))
        self._changed()

    def remove(self):
        sel = list(self.chosen.curselection())
        if not sel:
            return
        a, c = self.get_available(), self.get_chosen()
        a += [c[i] for i in sel]
        c = [x for i, x in enumerate(c) if i not in sel]
        self._fill(self.avail, a)
        self._fill(self.chosen, c)
        self._changed()

    def move(self, delta):
        items = self.get_chosen()
        marks = [i in set(self.chosen.curselection()) for i in range(len(items))]
        if not any(marks):
            return
        if delta < 0:                                   # up: walk top -> bottom
            for i in range(1, len(items)):
                if marks[i] and not marks[i - 1]:
                    items[i - 1], items[i] = items[i], items[i - 1]
                    marks[i - 1], marks[i] = marks[i], marks[i - 1]
        else:                                           # down: walk bottom -> top
            for i in range(len(items) - 2, -1, -1):
                if marks[i] and not marks[i + 1]:
                    items[i], items[i + 1] = items[i + 1], items[i]
                    marks[i], marks[i + 1] = marks[i + 1], marks[i]
        self._fill(self.chosen, items, [i for i, m in enumerate(marks) if m])
        self._changed()


def _append_log(widget, text):
    widget.configure(state="normal")
    widget.insert("end", text + "\n")
    widget.see("end")
    widget.configure(state="disabled")


def _log_box(parent):
    frame = ttk.Frame(parent)
    txt = tk.Text(frame, height=9, wrap="word", state="disabled", font=("TkFixedFont", 9))
    sb = ttk.Scrollbar(frame, orient="vertical", command=txt.yview)
    txt.configure(yscrollcommand=sb.set)
    txt.pack(side="left", fill="both", expand=True)
    sb.pack(side="right", fill="y")
    return frame, txt


class _Tab(ttk.Frame):
    """Shared bits: path rows, busy state, log."""

    def __init__(self, master, app):
        super().__init__(master, padding=8)
        self.app = app
        self.busy = False
        self.last_output = None

    def path_row(self, row, label, var, browse, extra_btn=None):
        ttk.Label(self, text=label).grid(row=row, column=0, sticky="w", padx=4, pady=3)
        ttk.Entry(self, textvariable=var).grid(row=row, column=1, sticky="ew", padx=4, pady=3)
        ttk.Button(self, text="Browse...", command=browse).grid(row=row, column=2, padx=4, pady=3)
        if extra_btn:
            ttk.Button(self, text=extra_btn[0], command=extra_btn[1]).grid(row=row, column=3, padx=4, pady=3)

    def say(self, text):
        _append_log(self.log, text)

    def set_busy(self, busy):
        self.busy = busy
        self.convert_btn.configure(state="disabled" if busy else "normal")
        if busy:
            self.progress.start(12)
        else:
            self.progress.stop()

    def open_out(self):
        if self.last_output and os.path.exists(self.last_output):
            open_folder(self.last_output)


XLSX = [("Excel files", "*.xlsx *.xlsm"), ("All files", "*.*")]

class ForwardTab(_Tab):
    def __init__(self, master, app):
        super().__init__(master, app)
        s = app.settings.get("forward", {})
        self.in_var = tk.StringVar(value=s.get("last_input", ""))
        self.out_var = tk.StringVar(value=s.get("last_output", ""))
        self.legacy_var = tk.BooleanVar(value=bool(s.get("legacy", False)))
        self.meta_var = tk.BooleanVar(value=bool(s.get("embed_meta", True)))
        self.extras, self.bom, self.loaded_path = [], [], None
        self._build()

    # ---- layout
    def _build(self):
        self.columnconfigure(1, weight=1)
        self.rowconfigure(3, weight=1)
        self.path_row(0, "Input (hierarchy):", self.in_var, self.browse_in,
                      ("Read columns", self.load_columns))
        self.path_row(1, "Output (BOM list):", self.out_var, self.browse_out)
        self.status = tk.StringVar(value="Choose the input file, then press 'Read columns'.")
        ttk.Label(self, textvariable=self.status, foreground="#555555").grid(
            row=2, column=0, columnspan=4, sticky="w", padx=4, pady=(2, 4))

        box = ttk.Frame(self)
        box.grid(row=3, column=0, columnspan=4, sticky="nsew")
        box.columnconfigure(0, weight=2, uniform="pick")
        box.columnconfigure(1, weight=5, uniform="pick")
        box.rowconfigure(0, weight=1)

        left = ttk.LabelFrame(box, text=" Parent columns  (BOM_COLUMNS) ", padding=6)
        left.grid(row=0, column=0, sticky="nsew", padx=(0, 6))
        left.columnconfigure(0, weight=1)
        left.rowconfigure(1, weight=1)
        ttk.Label(left, text="Select the columns that describe the PARENT.\nEach one gets an extra "
                             "'<column>-BOM (of)' column.", wraplength=250, justify="left"
                  ).grid(row=0, column=0, sticky="w", pady=(0, 4))
        self.bom_list = PickMany(left, on_change=self.on_bom_change)
        self.bom_list.grid(row=1, column=0, sticky="nsew")

        right = ttk.LabelFrame(box, text=" Output columns and order  (OUTPUT_COLUMN_ORDER) ", padding=6)
        right.grid(row=0, column=1, sticky="nsew")
        right.columnconfigure(0, weight=1)
        right.rowconfigure(0, weight=1)
        self.order = OrderPicker(right)
        self.order.grid(row=0, column=0, sticky="nsew")
        ttk.Label(right, text=ID_UM_HINT, foreground="#555555", wraplength=520, justify="left"
                  ).grid(row=1, column=0, sticky="w", pady=(4, 0))

        opts = ttk.Frame(self)
        opts.grid(row=4, column=0, columnspan=4, sticky="w", pady=(6, 0))
        ttk.Checkbutton(opts, text="Embed layout info for the reverse converter (hidden '_meta' sheet)",
                        variable=self.meta_var).pack(anchor="w")
        ttk.Checkbutton(opts, text="Old duplicate-assembly handling (exactly like g04071405.py)",
                        variable=self.legacy_var).pack(anchor="w")

        btns = ttk.Frame(self)
        btns.grid(row=5, column=0, columnspan=4, sticky="ew", pady=6)
        ttk.Button(btns, text="Reset to script defaults", command=self.reset_defaults).pack(side="left")
        ttk.Button(btns, text="Save choices", command=self.save_now).pack(side="left", padx=6)
        self.convert_btn = ttk.Button(btns, text="Convert", command=self.convert)
        self.convert_btn.pack(side="right")
        ttk.Button(btns, text="Open output folder", command=self.open_out).pack(side="right", padx=6)

        self.progress = ttk.Progressbar(self, mode="indeterminate")
        self.progress.grid(row=6, column=0, columnspan=4, sticky="ew")
        frame, self.log = _log_box(self)
        frame.grid(row=7, column=0, columnspan=4, sticky="ew", pady=(6, 0))

    # ---- file choosing
    def _dir(self, var):
        p = var.get().strip()
        return os.path.dirname(p) if p and os.path.dirname(p) else None

    def browse_in(self):
        p = filedialog.askopenfilename(title="Input hierarchy file", filetypes=XLSX,
                                       initialdir=self._dir(self.in_var))
        if p:
            self.in_var.set(p)
            if not self.out_var.get().strip():
                self.out_var.set(default_output_path(p, os.path.basename(F.OUTPUT_FILE)))
            self.load_columns()

    def browse_out(self):
        p = filedialog.asksaveasfilename(title="Save BOM list as", defaultextension=".xlsx",
                                         filetypes=XLSX, initialdir=self._dir(self.out_var),
                                         initialfile=os.path.basename(self.out_var.get() or F.OUTPUT_FILE))
        if p:
            self.out_var.set(p)

    # ---- column state
    def _state_for_reload(self):
        if self.extras:        # carry the current (maybe unsaved) choices over to the next file
            return forward_settings(self.bom, self.order.get_chosen(), self.extras,
                                    self.legacy_var.get(), self.meta_var.get(), "", "")
        return self.app.settings.get("forward", {})

    def load_columns(self, quiet=False):
        path = self.in_var.get().strip().strip('"')
        if not path or not os.path.isfile(path):
            if not quiet:
                messagebox.showwarning("Input file", "Please choose an existing input file.")
            return False
        try:
            cols, extras = F.read_columns(path)
        except Exception as e:                                  # noqa: BLE001
            if not quiet:
                messagebox.showerror("Cannot read the file", str(e))
            self.status.set(f"Cannot read {os.path.basename(path)}: {e}")
            return False
        low = {c.lower() for c in cols}
        missing = [r for r in ("level", "pn", "id") if r not in low]
        if missing:
            if not quiet:
                messagebox.showerror("Missing columns",
                                     f"The file needs the columns Level, PN and ID.\nMissing: {missing}\n"
                                     f"Found: {cols}")
            self.status.set(f"{os.path.basename(path)}: missing column(s) {missing}")
            return False
        st = initial_forward_state(extras, self._state_for_reload())
        self.extras, self.bom, self.loaded_path = extras, st["bom"], path
        self.bom_list.set_items(extras, st["bom"])
        self.order.set_items(st["available"], st["chosen"])
        self.status.set(f"{os.path.basename(path)}: {len(cols)} columns read, {len(extras)} can be parent columns.")
        for n in st["notes"]:
            self.say("Note: " + n)
        return True

    def on_bom_change(self):
        new_bom = self.bom_list.get_selected()
        chosen, avail = change_bom(self.order.get_chosen(), self.order.get_available(), self.bom, new_bom)
        self.bom = new_bom
        self.order.set_items(avail, chosen)

    def reset_defaults(self):
        if not self.extras:
            return
        st = initial_forward_state(self.extras, None)
        self.bom = st["bom"]
        self.bom_list.set_items(self.extras, st["bom"])
        self.order.set_items(st["available"], st["chosen"])
        self.legacy_var.set(False)
        self.meta_var.set(True)
        for n in st["notes"]:
            self.say("Note: " + n)
        self.say("Script defaults restored (not saved until you convert or press 'Save choices').")

    # ---- saving
    def current_settings(self):
        return forward_settings(self.bom, self.order.get_chosen(), self.extras, self.legacy_var.get(),
                                self.meta_var.get(), self.in_var.get().strip(), self.out_var.get().strip())

    def save_now(self, quiet=False):
        s = dict(self.app.settings.get("forward", {}))
        s.update({"legacy": bool(self.legacy_var.get()), "embed_meta": bool(self.meta_var.get()),
                  "last_input": self.in_var.get().strip(), "last_output": self.out_var.get().strip()})
        if self.extras:
            s.update(self.current_settings())
        self.app.settings["forward"] = s
        ok = self.app.write_settings()
        if not quiet:
            self.say(f"Choices saved to {F.settings_path()}" if ok else "Could not write the settings file.")

    # ---- conversion
    def convert(self):
        if self.busy:
            return
        inp = self.in_var.get().strip().strip('"')
        out = self.out_var.get().strip().strip('"')
        if not inp or not os.path.isfile(inp):
            messagebox.showwarning("Input file", "Please choose an existing input file.")
            return
        if not out:
            out = default_output_path(inp, os.path.basename(F.OUTPUT_FILE))
            self.out_var.set(out)
        if os.path.abspath(inp) == os.path.abspath(out):
            messagebox.showerror("Output file", "The output file must be different from the input file.")
            return
        if self.loaded_path != inp and not self.load_columns():
            return
        bom, chosen = list(self.bom), self.order.get_chosen()
        if not chosen:
            messagebox.showwarning("Output columns", "Choose at least one output column.")
            return
        self.save_now(quiet=True)
        legacy, meta = self.legacy_var.get(), self.meta_var.get()
        self.set_busy(True)
        self.say(f"--- Converting {os.path.basename(inp)}")

        def job(log):
            return F.convert_file(inp, out, bom_columns=bom, output_order=chosen, legacy=legacy,
                                  child_id=False, embed_meta=meta, append_rest=False, strict=True, log=log)

        def done(res):
            self.set_busy(False)
            self.last_output = out
            st = res["stats"]
            msg = f"Finished: {st['rows']} rows, {len(res['issues'])} issue(s) -> {out}"
            self.say(msg)
            self.status.set(msg)

        def failed(exc, tb):
            self.set_busy(False)
            self.say(f"ERROR: {exc}")
            messagebox.showerror("Conversion failed", str(exc))

        self.app.run_task(job, self.log, done, failed)


class ReverseTab(_Tab):
    def __init__(self, master, app):
        super().__init__(master, app)
        s = app.settings.get("reverse", {})
        self.in_var = tk.StringVar(value=s.get("last_input", ""))
        self.out_var = tk.StringVar(value=s.get("last_output", ""))
        self.collapse_var = tk.BooleanVar(value=bool(s.get("collapse", False)))
        self.columnconfigure(1, weight=1)
        self.rowconfigure(5, weight=1)
        self.path_row(0, "BOM list (input):", self.in_var, self.browse_in)
        self.path_row(1, "Hierarchy (output):", self.out_var, self.browse_out)
        ttk.Label(self, foreground="#555555", wraplength=760, justify="left",
                  text="Uses the BOM sheet written by the forward converter. Every product row (empty "
                       "'BOM (of)') is exploded into Level / PN / ID / R1.. / Priority / QTY / extra columns."
                  ).grid(row=2, column=0, columnspan=4, sticky="w", padx=4, pady=6)
        ttk.Checkbutton(self, variable=self.collapse_var,
                        text="List the content of a repeated assembly only the first time "
                             "(use it if the original file did not repeat it)"
                        ).grid(row=3, column=0, columnspan=4, sticky="w", padx=4)
        btns = ttk.Frame(self)
        btns.grid(row=4, column=0, columnspan=4, sticky="ew", pady=8)
        self.convert_btn = ttk.Button(btns, text="Convert", command=self.convert)
        self.convert_btn.pack(side="right")
        ttk.Button(btns, text="Open output folder", command=self.open_out).pack(side="right", padx=6)
        frame, self.log = _log_box(self)
        frame.grid(row=5, column=0, columnspan=4, sticky="nsew")
        self.progress = ttk.Progressbar(self, mode="indeterminate")
        self.progress.grid(row=6, column=0, columnspan=4, sticky="ew", pady=(6, 0))

    def browse_in(self):
        p = filedialog.askopenfilename(title="BOM list file", filetypes=XLSX,
                                       initialdir=os.path.dirname(self.in_var.get()) or None)
        if p:
            self.in_var.set(p)
            if not self.out_var.get().strip():
                self.out_var.set(default_output_path(p, os.path.basename(R.OUTPUT_FILE)))

    def browse_out(self):
        p = filedialog.asksaveasfilename(title="Save hierarchy as", defaultextension=".xlsx",
                                         filetypes=XLSX, initialdir=os.path.dirname(self.out_var.get()) or None,
                                         initialfile=os.path.basename(self.out_var.get() or R.OUTPUT_FILE))
        if p:
            self.out_var.set(p)

    def save_now(self, quiet=True):
        self.app.settings["reverse"] = {"last_input": self.in_var.get().strip(),
                                        "last_output": self.out_var.get().strip(),
                                        "collapse": bool(self.collapse_var.get())}
        self.app.write_settings()

    def convert(self):
        if self.busy:
            return
        inp = self.in_var.get().strip().strip('"')
        out = self.out_var.get().strip().strip('"')
        if not inp or not os.path.isfile(inp):
            messagebox.showwarning("Input file", "Please choose an existing BOM list file.")
            return
        if not out:
            out = default_output_path(inp, os.path.basename(R.OUTPUT_FILE))
            self.out_var.set(out)
        if os.path.abspath(inp) == os.path.abspath(out):
            messagebox.showerror("Output file", "The output file must be different from the input file.")
            return
        self.save_now()
        collapse = self.collapse_var.get()
        self.set_busy(True)
        self.say(f"--- Rebuilding the hierarchy from {os.path.basename(inp)}")

        def job(log):
            return R.rebuild_file(inp, out, collapse=collapse, log=log)

        def done(res):
            self.set_busy(False)
            self.last_output = out
            self.say(f"Finished: {res['stats']['rows']} rows -> {out}")

        def failed(exc, tb):
            self.set_busy(False)
            self.say(f"ERROR: {exc}")
            messagebox.showerror("Conversion failed", str(exc))

        self.app.run_task(job, self.log, done, failed)


class App(tk.Tk):
    def __init__(self, initial_tab="forward"):
        if sys.platform.startswith("win"):
            try:
                import ctypes
                ctypes.windll.shcore.SetProcessDpiAwareness(1)
            except Exception:                               # noqa: BLE001
                pass
        super().__init__()
        self.title("BOM converter")
        self.geometry("1020x780")
        self.minsize(860, 640)
        self.settings = F.load_settings()
        self.q = queue.Queue()
        style = ttk.Style(self)
        if sys.platform != "darwin":
            for theme in ("vista", "clam"):
                if theme in style.theme_names():
                    style.theme_use(theme)
                    break
        self.nb = ttk.Notebook(self)
        self.nb.pack(fill="both", expand=True, padx=8, pady=8)
        self.forward = ForwardTab(self.nb, self)
        self.reverse = ReverseTab(self.nb, self)
        self.nb.add(self.forward, text="  Hierarchy  ->  BOM list  ")
        self.nb.add(self.reverse, text="  BOM list  ->  Hierarchy  ")
        if initial_tab == "reverse":
            self.nb.select(self.reverse)
        self.protocol("WM_DELETE_WINDOW", self.on_close)
        self._poll_id = self.after(80, self._poll)
        self.after(150, self._startup)

    def _startup(self):
        p = self.forward.in_var.get().strip()
        if p and os.path.isfile(p):                  # prefill the pickers from the last session
            self.forward.load_columns(quiet=True)

    def write_settings(self):
        self.settings["version"] = 1
        return F.save_settings(self.settings)

    def run_task(self, fn, log_widget, on_done, on_error):
        def logger(*a):
            self.q.put(("log", log_widget, " ".join(str(x) for x in a)))

        def work():
            try:
                res = fn(logger)
            except Exception as e:                      # noqa: BLE001
                self.q.put(("error", on_error, e, traceback.format_exc()))
            else:
                self.q.put(("done", on_done, res))

        threading.Thread(target=work, daemon=True).start()

    def _poll(self):
        try:
            while True:
                msg = self.q.get_nowait()
                if msg[0] == "log":
                    _append_log(msg[1], msg[2])
                elif msg[0] == "done":
                    msg[1](msg[2])
                else:
                    msg[1](msg[2], msg[3])
        except queue.Empty:
            pass
        self._poll_id = self.after(80, self._poll)

    def on_close(self):
        self.forward.save_now(quiet=True)
        self.reverse.save_now()
        try:
            self.after_cancel(self._poll_id)
        except Exception:                                   # noqa: BLE001
            pass
        self.destroy()


def main(initial_tab="forward"):
    if TK_ERROR:
        print(f"The window needs tkinter, which is not available in this Python ({TK_ERROR}).\n"
              f"On Linux install the 'python3-tk' package. The scripts still work from the command line.")
        return 1
    App(initial_tab).mainloop()
    return 0


if __name__ == "__main__":
    sys.exit(main())

